package com.perscholas.sba;

import java.util.ArrayList;
import java.util.Scanner;

public class Compression {

	static String string1, compressedString;
	static ArrayList<String> templist = new ArrayList<String>();
	static char[] sortArray;
	static char temp;
	static int counter = 1, j = 0;
	static Scanner scan = new Scanner(System.in);

	public Compression() {

	}

	protected void compression() {
		string1 = "";
		compressedString = "";
		templist = new ArrayList<String>();
		sortArray = new char[string1.length()];
		temp = ' ';
		counter = 1;
		j = 0;
		scan = new Scanner(System.in);

	}

//==============Main==========================	
	/**
	 * takes an input string, then converts it to a char array. then set temp char
	 * as the first char in sortArray loop will calling check method to see if there
	 * are consecutive same chars. if statement to see if there are consecutive
	 * chars, then add them into an ArrayList. reset counte,r iterate next Arraylist
	 * spot, set temp to new char in list that is not consecutive, display
	 * arraylist.
	 * 
	 * @param args
	 */
	public void problem1Com() {
		compression();
		System.out.println("enter a word");

		string1 = scan.next();
		System.out.println(string1);

		sortArray = new char[string1.length()];

		sortArray = string1.toCharArray();

		temp = sortArray[0];

		try {
			for (int i = 1; i < sortArray.length; i++) {
				if (!check(sortArray[i])) {
					// if temp char is same as sortArray[i], continue iterating
					// if not: check if consecutive char or not
					// then put char in ArrayList with number of consecutive char if applicable.

					if (counter == 1) {
						templist.add(Character.toString(temp));
					} else {
						String s = Integer.toString(counter);
						templist.add(Character.toString(temp) + s);
					}

					j++;
					if (temp != sortArray[i])
						temp = sortArray[i];
					counter = 1;
					System.out.println(temp + " " + i); // check current temp value and iteration
				} else {

					System.out.println(counter);
					continue;
				}
			}
		} catch (Exception e) {

		} finally {
		}
		// if check method returns false:
		// then if statement to see if check char is last,
		// then put into Arraylist.

		if (temp == sortArray[sortArray.length - 1]) {

			if (counter == 1) {
				templist.add(Character.toString(temp));
			} else if (counter > 1) {
				char c = sortArray[sortArray.length - 1];
				String s = Integer.toString(counter);
				templist.add(Character.toString(c) + s);
			}

		}

		System.out.println("templist size " + templist.size());

		for (int k = 0; k < templist.size(); k++) {
			compressedString += templist.get(k);
		}
		String compS = compressedString.replaceAll("null", "");
		System.out.println(templist);
		System.out.println(string1 + " " + string1.length() + " " + compS + " " + compS.length());

	}

//===================boolean check method====================
	/**
	 * 
	 * @param cha passing the current value of sortArray at i spot
	 * @return true if current value of sortArray is same as set temp char. false if
	 *         current sortArray value is differnt
	 */
	private static boolean check(char cha) {
		// checking iterations
		System.out.println(temp + "vs" + cha + " counter: " + counter);

		if (temp == cha) {
			counter++;
			return true;
		} else if (cha == sortArray[sortArray.length - 1]) {
			return false;

		} else {

			return false;
		}

	}

}
