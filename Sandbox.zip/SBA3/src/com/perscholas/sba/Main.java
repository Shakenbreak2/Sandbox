package com.perscholas.sba;

import java.util.Scanner;

public class Main {

	static Scanner scan = new Scanner(System.in);
	static boolean out=true;
	public static void main(String[] args) {
		do {
		System.out.println("Which problem do you wish to see: problem1, problem2, exit.");
		String string=scan.next();
		
		switch(string) {
		case "problem1":problem1();out=false;break;
		case "problem2":problem2();out=false;break;
		case "exit":out=true;break;
			default:out=false;break;
		}
		}while(out==false);
		
		scan.close();
	}
	
	private static void problem1() {
		Compression start =new Compression();
		start.problem1Com();
	}
	
	private static void problem2() {
		Usernames start = new Usernames();
		start.problem2Com();
	}

}
