package com.perscholas.sba;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Scanner;

public class Usernames {

	private static List<String> usernames = new ArrayList<String>();
	private static String name = "", newName = "";

	static Scanner input = new Scanner(System.in);

	static int i = 1, j=1;

	public void problem2Com() {

		boolean again = true;
		/**
		 * Create the username portion of a registration system that requires all
		 * usernames are unique. If a new user requests a name that is already used, an
		 * integer should be added to the end of the username to make it unique. The
		 * numbering begins with 1 and is incremented by 1 for each new instance per
		 * username.
		 * 
		 * As an example, if username requests were for [bob, alice, bob, alice, bob,
		 * alice], the system should assign usernames [bob, alice, bob1, alice1, bob2,
		 * alice2].
		 * 
		 * Given a list of username requests in the order given, process all requests
		 * and return an array of the usernames as assigned by the function.
		 * 
		 * Constraints
		 * 
		 * At least use one Data Structure from Java Collections or Map username
		 * contains only lowercase English letters in the range ascii[a-z].
		 * 
		 */

		//	do-while loop to keep adding names to list
		do {

			//prompt user for name and get user input
			System.out.println("hello enter your username, ");
			name = input.next().toLowerCase().trim();
			
			//check if name is already in table
			if (!usernames.contains(name)) {
				
				//if name is not in table add name
				usernames.add(name);
				
				//reset counter for adding 
				i=1;
			} else {
				
				//if name is already use check method to see if name + i is, so on
				System.out.println(name+" already used, trying "+name+i);
				if(check(name,i)) {
					//if name i+1 is not used add to table
				usernames.add(newName);
				}

				
			}

			//print out tables
			System.out.println(usernames);
			
			//prompt user to see if want to enter another name.
			System.out.println("do you wish to enter another. yes, no");
			String f = input.next().toLowerCase().trim();
			
			//if switch toggles boolean flag for do-while loop
			switch(f) {
			case "yes":again=true;break;
			case "no":again=false;break;
			default:again=false;break;
			}

		} while (again == true);
		System.out.println("goodbye");

	}

	/**	checks username table to see if name with number attached is used.
	 * 
	 * @param string input name from user to check name
	 * @param j is iteration for number to attach to name
	 * @return true if name with j is not used in table
	 */
	private static boolean check(String string, int j) {
		String name2 = string.concat(Integer.toString(j));
		//name2 is equal to input string with number attached
		
		//check name2 if in username table
		if (!usernames.contains(name2)) {
			
			//return true, set newName to name2
			newName=name2;
			return true;
			
			//name2 is used iterate j +1 and check input string with new number
		} else if(usernames.contains(name2)){
			System.out.println("username already used trying: " + string+ ++j); 
			return check(string, j);
		}else
			//default return true
		return true;

	}


}
