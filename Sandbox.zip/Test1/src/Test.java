import java.util.Collections;
import java.util.LinkedList;
import java.util.List;

public class Test {

	public static void main(String[] args) {
//		List<Integer> a=Arrays.asList(3,4,6,7,9,12,15,17,23);
//		List<Integer> b=Arrays.asList(3,5,7,9,10,13,15,18,23);
//		List<Integer> c=new ArrayList<Integer>();
//		
		List<Integer> c1 = new LinkedList<Integer>();
		List<Integer> c2 = new LinkedList<Integer>();
		List<Integer> c3 = new LinkedList<Integer>();
		
		for(int i=0;i<10;i++) {
			if(i != 0) {
				c1.add(i);
			}
			if(i%2==0 || i%3==0) {
				c2.add(i);
			}
		}
		
		c3.addAll(c1);
		c3.addAll(c2);
		System.out.println(c3);
		Collections.sort(c3);
		System.out.println(c3);
		
		
	}

}
