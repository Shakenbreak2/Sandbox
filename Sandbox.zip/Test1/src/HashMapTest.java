import java.util.HashMap;

public class HashMapTest {

	public static void main(String[] args) {
		HashMap<Integer, String> map = new HashMap<Integer, String>();
		
		map.put(1, "Valli");
		map.put(2, "Swathi");
		map.put(3, "Shravani");
		
		System.out.println(map);
		
		for(int i: map.keySet()) {
			System.out.println(i);
		}
		
		for(String i: map.values()) {
			System.out.println(i);
		}
		
		map.forEach((key,values) -> {
			System.out.println(key);
		});
	}

}
