import java.util.Scanner;

public class D1Array {

	public static void main(String[] args) {
		int studentsNo = 0;
		int examNo = 0;
		double sum = 0;

		// scanner object
		Scanner in = new Scanner(System.in);

		// array input
		System.out.println("how many students are there?");
		studentsNo = in.nextInt();
		System.out.println("how many exams are there?");
		examNo = in.nextInt();

		// declare arrays
		String[] name = new String[studentsNo];
		double[][] score = new double[studentsNo][examNo];
		double[] studAvg = new double[studentsNo];

		// inputs
		for (int i = 0; i < studentsNo; i++) {
			System.out.println("enter student name:");
			name[i] = in.next();// enter student name into name array

			for (int j = 0; j < examNo; j++) {
				System.out.println("enter student's score #" + (j + 1));
				score[i][j] = in.nextDouble();// enter students's score into array
				sum += score[i][j];//calc total sum of all exams
				
			}
			studAvg[i] = sum/examNo;//store exams averages
			sum = 0;//reset sum

		}

		// outputs
		// ex. name: Darril, scores: 45 56 67 87 score avg: 63.75
		for (int i = 0; i < studentsNo; i++) {
			System.out.print("name: " + name[i] + ", score: ");
			for (int j = 0; j < examNo; j++) {
				System.out.print(score[i][j] + " ");
			}
			System.out.print("score avg: " + studAvg[i]);
			System.out.println();
		}

		// close scanner
		in.close();
	}

}
