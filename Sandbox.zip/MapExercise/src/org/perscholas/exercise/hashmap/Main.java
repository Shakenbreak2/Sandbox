package org.perscholas.exercise.hashmap;

import java.util.HashMap;
import java.util.Scanner;
import java.util.function.BiFunction;

public class Main {

	public static void main(String[] args) {
		HashMap<String, ItemObject> cart = new HashMap<String, ItemObject>();
		
		boolean again = false;
		Scanner input = new Scanner(System.in);
		do {

			System.out.println("Add item to cart");
			String item_name = input.next();
			System.out.println("What is the price of the item");
			double item_price = input.nextDouble();
			System.out.println("How many do you wish to add");
			int item_quantity = input.nextInt();

			ItemObject item = new ItemObject(item_name, item_price, item_quantity);

			if (cart.containsKey(item_name)) {
				replaceItem(cart, item_name, item_quantity);
			} else {
				cart.put(item_name, item);
			}
			
			for(String name: cart.keySet()) {
				String key=name.toString();
				ItemObject value=cart.get(name);
				System.out.println(key+" price: "+value.getItem_price()+" quantity: "+value.getItem_quantity());
			}
			
			System.out.println("do you wish to add another item \n 0 for yes \n 1 for no");
			int i = input.nextInt();
			switch (i) {
			case 0:
				again = true;
				break;
			case 1:
				again = false;
				break;
			default:
				again = false;
				break;
			}
		} while (again == true);
		input.close();
	}

	public static void replaceItem(HashMap<String, ItemObject> cart, String item_name, int item_quantity) {
		ItemObject newitem = cart.get(item_name);
		int quantity = newitem.getItem_quantity() + item_quantity;
		newitem.setItem_quantity(quantity);
		cart.replace(item_name, newitem);
	}

}
