package org.perscholas.exercise.hashmap;

public class ItemObject {
	private String item_name;
	private double item_price;
	private int item_quantity;
	
	public ItemObject() {
		// TODO Auto-generated constructor stub
	}

	public ItemObject(String item_name, double item_price, int item_quantity) {
		super();
		this.item_name = item_name;
		this.item_price = item_price;
		this.item_quantity = item_quantity;
	}

	/**
	 * @return the item_name
	 */
	public String getItem_name() {
		return item_name;
	}

	/**
	 * @param item_name the item_name to set
	 */
	public void setItem_name(String item_name) {
		this.item_name = item_name;
	}

	/**
	 * @return the item_price
	 */
	public double getItem_price() {
		return item_price;
	}

	/**
	 * @param item_price the item_price to set
	 */
	public void setItem_price(double item_price) {
		this.item_price = item_price;
	}

	/**
	 * @return the item_quantity
	 */
	public int getItem_quantity() {
		return item_quantity;
	}

	/**
	 * @param item_quantity the item_quantity to set
	 */
	public void setItem_quantity(int item_quantity) {
		this.item_quantity = item_quantity;
	}

}
