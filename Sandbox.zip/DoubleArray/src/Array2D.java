
public class Array2D {
static String[][] arr = {{"*","dar","*"},{"*","*","*"}};

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String name="dar";
		display(name);
		
	
	
	}
	
	static void display(String name){
		for(int i=0;i<arr.length;i++) {
			for(int j=0;j<arr.length;j++) {
				if(arr[i][j].equals(name)) {
					System.out.println(name+" is at "+i+" , "+j);
//					break;
				}
				
			}
		}
	}
}
