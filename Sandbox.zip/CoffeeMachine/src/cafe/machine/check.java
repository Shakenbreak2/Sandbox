package cafe.machine;

public class check {

}
