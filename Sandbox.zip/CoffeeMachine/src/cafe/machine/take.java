package cafe.machine;

import java.util.Scanner;

public class take {
//	static int cups = 0, water = 0, milk = 0, money = 0, beans = 0;
	static Scanner input = new Scanner(System.in);

	static int takeBeans(int beans) {
		System.out.println("How many beans do you wish to take?");
		int take = input.nextInt();
		if (take > beans)
			beans = 0;
		else
			beans -= take;
		
		return beans;
	}

	static void takeCups(int cups) {
		System.out.println("How many cups do you wish to take?");
		int take = input.nextInt();
		if (take > cups)
			cups = 0;
		else
			cups -= take;
	}

	static void takeWater(int water) {
		System.out.println("How many water do you wish to take?");
		int take = input.nextInt();
		if (take > water)
			water = 0;
		else
			water -= take;
	}

	static int takeMilk(int milk) {
		System.out.println("How many milk do you wish to take?");
		int take = input.nextInt();
		if (take > milk)
			milk = 0;
		else
			milk -= take;
		
		return milk;
	}

	static int takeMoney(int money) {
		System.out.println("How many money do you wish to take?");
		int take = input.nextInt();
		if (take > money)
			System.out.println("there is not enough money in vending machine");
		else
			money -= take;
		
		return money;
	}

}
