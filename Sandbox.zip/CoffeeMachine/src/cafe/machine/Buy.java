package cafe.machine;

import java.util.Scanner;

public class Buy {
	static int espresso, cappuccino, latte;
	static int beansCost, cupsCost, waterCost, milkCost, moneyCost;

	static Scanner input = new Scanner(System.in);
	
	public Buy() {
		espresso = 0;
		cappuccino = 0;
		latte = 0;
		
	}

	// add espresso
	static int espresso(int cups,int water,int milk,int money,int beans) {
		//used to determine if there is enough resources in the machine
		beansCost = 200;
		cupsCost = 1;
		waterCost = 473;
		milkCost = 30;
		
		//prompt to get number of coffees
		System.out.println("how many espressos do you want?");
		int amount = input.nextInt();// enter amount of coffee wanted
		
		//multiply above by input value for calculations later
		beansCost *= amount;
		cupsCost *= amount;
		waterCost *= amount;
		milkCost *= amount;
		
		//call calcResources method to see if there is enough resources in machine
		if (calcResources(milkCost, milk, beansCost, beans, waterCost, water, cupsCost, cups)) {
			espresso += amount;//if there are enough resources add amount entered above to total

			System.out.printf("you ordered %d espresso(s)\n", espresso);
		} 
		//return total amount of espressos back to CafeMachine.
		return espresso;
	}

	// add cappuccino
	static int cappuccino(int cups,int water,int milk,int money,int beans) {
		//intialize values for
		beansCost = 140;
		cupsCost = 1;
		waterCost = 473;
		milkCost = 20;
		
		System.out.println("how many cappuccinos do you want?");
		int amount = input.nextInt();
		
		beansCost *= amount;
		cupsCost *=amount;
		waterCost *=amount;
		milkCost *=amount;
		if(calcResources(milkCost, milk, beansCost, beans, waterCost, water, cupsCost, cups)) {
			
		}
		cappuccino += amount;
//		teaCost += (amount * 1.5);
		System.out.printf("you ordered %d cappuccino(s)\n", cappuccino);
		return cappuccino;
	}

	// add latte
	static int latte(int cups,int water,int milk,int money,int beans) {
		beansCost = 130;
		cupsCost = 1;
		waterCost = 473;
		milkCost = 50;
		
		System.out.println("how many lattes do you want?");
		int amount = input.nextInt();
		
		beansCost *= amount;
		cupsCost *= amount;
		waterCost *= amount;
		milkCost *= amount;
		if (calcResources(milkCost, milk, beansCost, beans, waterCost, water, cupsCost, cups)) {

		}
		latte += amount;

		System.out.printf("you ordered %d latte(s)\n", latte);
		return latte;
	}

	//used to see if there is enough resources in the machine
	static boolean calcResources(int milkCost, int milk, int beansCost, int beans, int waterCost, int water,
			int cupsCost, int cups) {
		boolean buy = false;

		//all conditions must be true to return true value
		if (milk > milkCost) {
			if (beans > beansCost) {
				if (water > waterCost) {
					if (cups > cupsCost) {

						buy = true;
					} else {
						System.out.println("not enough cups");
						buy = false;
					}
				} else {
					System.out.println("not enough water");
					buy = false;
				}

			} else {
				System.out.println("not enough beans");
				buy = false;
			}

		} else {
			System.out.println("not enough milk");
			buy = false;
		}
		
		return buy;
	}

}
