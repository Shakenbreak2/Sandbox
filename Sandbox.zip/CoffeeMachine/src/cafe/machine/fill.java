package cafe.machine;

public class fill {

	public static void fillMachine() {
////		System.out.printf("%f beans, \n%f cups, \n%f liters of water, \n%f liters of milk, \n%f dollars in vending machine.\n", beans, cups, water, milk, money);
//		System.out.println("how many beans do you wish to refill");
//		beans += input.nextInt();
//		
//		System.out.println("how many cups do you wish to refill");
//		cups += input.nextInt();
//		System.out.println("how much water do you wish to refill");
//		water += input.nextInt();
//		System.out.println("how much milk do you wish to refill");
//		milk += input.nextInt();
//		
	}
}
