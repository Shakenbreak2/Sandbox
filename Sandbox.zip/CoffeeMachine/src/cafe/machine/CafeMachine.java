package cafe.machine;

import java.util.Scanner;
import java.util.regex.Pattern;

public class CafeMachine {
	// public variables
	static Scanner input = new Scanner(System.in);
	static int espresso = 0, cappuccino = 0, latte = 0, cups = 20, water = 400, milk = 300, money = 100, beans=700;
	static double cost = 0.00, espressoCost = 0, cappuccinoCost = 0, latteCost = 0;
	static boolean quit = false;
	// ==============
	// main method
	public static void main(String[] args) {

		boolean quit = false;

		// ordering loop
		do {
			quit = menu(quit);
			// performs ordering and returns a
			// boolean to either quit ordering or order again
		} while (quit == false);

		// calculate total cost
		cost = espressoCost +  cappuccinoCost + latteCost;
		// closing scanner
		input.close();
		// output final order
		System.out.printf("Here is your order. " + "\n%d coffees - $%.2f,\n%d teas - $%.2f,\n%d sandwiches - $%.2f \n"
				+ "your total is %.2f", espresso, espressoCost, cappuccino, cappuccinoCost, latte, latteCost, cost);
	}

	static boolean menu(boolean quit) {
		String order;

		// ordering loop

		System.out.println("Write action -buy, -fill, -take, -check, -exit): ");
		order = input.next();

		switch (order) {
		case "buy":
			order();
			quit=false;
			break;
		case "fill":
			fill();
			quit=false;
			break;
		case "take":
			take();
			quit=false;
			break;
		case "check":
			check();
			quit=false;
			break;
		case "exit":
			quit = true;
			break;
		default:
			System.out.println("enter a valid option.");
		}

		// performs ordering and returns a
		// boolean to either quit ordering or order again

		return quit;
	}

	// order loop, goes to buy.java
	static void order() {
		String menu;
		boolean exit=false;
		do {
			System.out.println("Welcome to my cafe please choose from our menu." + "\n1)espresso $4/e"
					+ "\n2)cappuccino $5/e" + "\n3)latte $4/e" + "\n4)back");

			menu = input.next().toLowerCase().trim();
			
			switch (menu) {
			case "1":
				espresso+=buy.espresso (cups, water, milk, money, beans);
				espressoCost= espresso*5;
				beans -= (200*espresso);
				cups -= (1*espresso);
				water -= (473*espresso);
				milk -= (30*espresso);
				money += (5*espresso);
				break;
			case "2":
				cappuccino+=buy.cappuccino( cups, water, milk, money, beans);
				cappuccinoCost= cappuccino*3;
				beans -= (140*espresso);
				cups -= (1*espresso);
				water -= (473*espresso);
				milk -= (20*espresso);
				money += (3*espresso);
				break;
			case "3":
				latte+=buy.latte( cups, water, milk, money, beans);
				latteCost= latte*4;
				beans -= (130*espresso);
				cups -= (1*espresso);
				water -= (473*espresso);
				milk -= (50*espresso);
				money += (4*espresso);
				break;
			case "4":
				exit = true;
				break;
			default:
				System.out.println("enter a valid option.");
			}

		} while (exit == false);
	}

	//goes to fill.java
	static void fill() {
		System.out.println("how many beans do you wish to refill");
		beans += input.nextInt();
		
		System.out.println("how many cups do you wish to refill");
		cups += input.nextInt();
		System.out.println("how much water do you wish to refill");
		water += input.nextInt();
		System.out.println("how much milk do you wish to refill");
		milk += input.nextInt();
		
	}

	//goes to take.java
	static void take() {
		System.out.println("What do you wish to take?"
				+ "\n1)beans"
				+ "\n2)water"
				+ "\n3)milk"
				+ "\n4)cups"
				+ "\n5)money");
		int takeChoice = input.nextInt();
		switch(takeChoice) {
		case 1:take.takeBeans(beans);
		case 2:take.takeWater(water);
		case 3:take.takeMilk(milk);
		case 4:take.takeCups(cups);
		case 5:take.takeMoney(money);
			default:System.out.println("not valid option");
				
		}
		
	}

	static void check() {
		System.out.printf("There is %d beans, "
				+ "\n%d cups, "
				+ "\n%d liters of water, "
				+ "\n%d liters of milk, "
				+ "\n%d dollars in vending machine.\n", beans, cups, water, milk, money);
	}
}
