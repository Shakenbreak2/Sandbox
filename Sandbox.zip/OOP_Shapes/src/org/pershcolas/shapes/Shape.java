package org.pershcolas.shapes;

public class Shape implements Ishapes{

	protected double height;
	protected double length;
	protected double width;
	
	public Shape() {
		this.height=1.0;
		this.length=1.0;
		this.width=1.0;
	}
	
	public double area() {
		return height * length* width;
	}

	/**
	 * @return the height
	 */
	public double getHeight() {
		return height;
	}

	/**
	 * @param height the height to set
	 */
	public void setHeight(double height) {
		this.height = height;
	}

	/**
	 * @return the length
	 */
	public double getLength() {
		return length;
	}

	/**
	 * @param length the length to set
	 */
	public void setLength(double length) {
		this.length = length;
	}

	/**
	 * @return the width
	 */
	public double getWidth() {
		return width;
	}

	/**
	 * @param width the width to set
	 */
	public void setWidth(double width) {
		this.width = width;
	}

	@Override
	public void setRadius(double d) {
		// TODO Auto-generated method stub
		
	}

	
	

}
