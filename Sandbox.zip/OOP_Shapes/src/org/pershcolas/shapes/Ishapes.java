/**
 * 
 */
package org.pershcolas.shapes;

/**
 * @author Darril
 *
 */
public interface Ishapes {

	
	double area();

	void setRadius(double d);

	void setHeight(double d);
	
	void setLength(double d);
	
	void setWidth(double d); 

}
