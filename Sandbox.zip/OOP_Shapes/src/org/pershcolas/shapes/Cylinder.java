package org.pershcolas.shapes;

public class Cylinder extends Shape implements Ishapes{

	private double radius;
	public Cylinder() {
		// TODO Auto-generated constructor stub
	}
	
	@Override
	public double area()
	{
		radius=width/2;
		return (Math.PI*(radius*radius)*height);
		
	}

	/**
	 * @return the radius
	 */
	public double getRadius() {
		return radius;
	}

	/**
	 * @param radius the radius to set
	 */
	public void setRadius(double radius) {
		this.radius = radius;
	}

}
