package org.pershcolas.shapes;

public class Main {

	public static void main(String[] args) {
		Ishapes cylinder = new Cylinder();
		Ishapes sphere = new Sphere();
		Ishapes circle = new Circle();
		Ishapes square = new Shape();
		Ishapes box = new Shape();
		
		square.setHeight(5);
		square.setLength(5.0);
		System.out.println("squre area: "+square.area());
		
		box.setHeight(5);
		box.setLength(5);
		box.setWidth(5);
		System.out.println("box volume: "+box.area());
		
		cylinder.setWidth(10.0);
		cylinder.setHeight(5.0);
		System.out.println("cylinder volume: "+cylinder.area());
		
		sphere.setWidth(10.0);
		System.out.println("sphere volume: "+sphere.area());
		
		circle.setWidth(10.0);
		System.out.println("circle area: "+circle.area());
	}

}
