package org.pershcolas.shapes;

public class Sphere extends Shape implements Ishapes{

	private double radius;
	
	public Sphere() {
		// TODO Auto-generated constructor stub
	}
	
	@Override
	public double area() {
		radius=width/2;
		double r3 = radius*radius*radius;
		double area = (4*Math.PI*r3)/3;
		return area;
		
	}

	/**
	 * @return the radius
	 */
	public double getRadius() {
		return radius;
	}

	/**
	 * @param radius the radius to set
	 */
	public void setRadius(double radius) {
		this.radius = radius;
	}

}
