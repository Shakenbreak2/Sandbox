package com.perscholas.java_basics;

public class IndexClass {

	public static void main(String[] args) {
		int num1=2,num2=3,sum=0;
		double dou1=2.2,dou2=3.3,douSum=0.0;
		
		sum=num1+num2;
		System.out.println(num1+" + "+num2+" = "+sum);
		douSum=dou1+dou2;
		System.out.println(dou1+" + "+dou2+" = "+douSum);
		
		douSum=num1+dou2;//num1 gets converted to double to equal as double
		System.out.printf("%d + %f = %f",num1,dou2,douSum);
		sum=(int)dou1+num2;//dou1 must be typecast as int to equal as sum
		System.out.printf("%f + %d = %d",dou1,num2,sum);
		
		
	}

}
