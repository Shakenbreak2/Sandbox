package org.perscholas.struct;

public class Person {
	private String name;
	private int age;
	private String company;
	private String job;
	private String hobby;
	
	public Person() {
		// TODO Auto-generated constructor stub
	}
	
	public Person(String name, int age, String company, String job, String hobby) {
		this.name = name;
		this.age = age;
		this.company = company;
		this.job = job;
		this.hobby = hobby;
	}

	public void talkAboutYourself() {
		System.out.println("hi, I'm "+ name+".");
		System.out.println("I'm "+age+" years old");
		System.out.println("I work at "+company+" as a "+job+".");
		System.out.println("When I get some free time, I like to "+hobby+".");
	}

	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * @return the age
	 */
	public int getAge() {
		return age;
	}

	/**
	 * @param age the age to set
	 */
	public void setAge(int age) {
		this.age = age;
	}

	/**
	 * @return the company
	 */
	public String getCompany() {
		return company;
	}

	/**
	 * @param company the company to set
	 */
	public void setCompany(String company) {
		this.company = company;
	}

	/**
	 * @return the job
	 */
	public String getJob() {
		return job;
	}

	/**
	 * @param job the job to set
	 */
	public void setJob(String job) {
		this.job = job;
	}

	/**
	 * @return the hobby
	 */
	public String getHobby() {
		return hobby;
	}

	/**
	 * @param hobby the hobby to set
	 */
	public void setHobby(String hobby) {
		this.hobby = hobby;
	}

}
