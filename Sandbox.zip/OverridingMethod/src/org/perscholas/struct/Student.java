package org.perscholas.struct;

public class Student extends Person{
	
	private String school;
	private String classroom;
	private int	id;
	private double score;
	private double score2;
	private double score3;
	
	
	public Student() {
		// TODO Auto-generated constructor stub
	}

	public Student(String name, int age, String company, String job, String hobby) {
		super(name, age, company, job, hobby);
		// TODO Auto-generated constructor stub
	}
	
	public Student(String school, String classroom, int id, double score, double score2, double score3) {
		this.school = school;
		this.classroom = classroom;
		this.id = id;
		this.score = score;
		this.score2 = score2;
		this.score3 = score3;
	}
	
	public double getTotal() {
		return score+score2+score3;
	}
	
	public double getAvg() {
		return score+score2+score3/3;
	}

	/**
	 * @return the school
	 */
	public String getSchool() {
		return school;
	}

	/**
	 * @param school the school to set
	 */
	public void setSchool(String school) {
		this.school = school;
	}

	/**
	 * @return the classroom
	 */
	public String getClassroom() {
		return classroom;
	}

	/**
	 * @param classroom the classroom to set
	 */
	public void setClassroom(String classroom) {
		this.classroom = classroom;
	}

	/**
	 * @return the id
	 */
	public int getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(int id) {
		this.id = id;
	}

	/**
	 * @return the score
	 */
	public double getScore() {
		return score;
	}

	/**
	 * @param score the score to set
	 */
	public void setScore(double score) {
		this.score = score;
	}

	/**
	 * @return the score2
	 */
	public double getScore2() {
		return score2;
	}

	/**
	 * @param score2 the score2 to set
	 */
	public void setScore2(double score2) {
		this.score2 = score2;
	}

	/**
	 * @return the score3
	 */
	public double getScore3() {
		return score3;
	}

	/**
	 * @param score3 the score3 to set
	 */
	public void setScore3(double score3) {
		this.score3 = score3;
	}
	

}
