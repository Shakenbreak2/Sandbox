package org.perscholas.struct;
import java.util.Scanner;

public class OverridingMethod {

	public static void main(String[] args) {
		
	}
	

}
