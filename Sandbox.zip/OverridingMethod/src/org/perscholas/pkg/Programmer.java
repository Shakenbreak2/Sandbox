package org.perscholas.pkg;
import org.perscholas.struct.*;

public class Programmer extends Person {
	private String programLanguage;
	
	public Programmer(String name, int age, String company, String job, String hobby, String programLanguage) {
		super(name, age, company, job, hobby);
		this.programLanguage=programLanguage;
		// TODO Auto-generated constructor stub
	}

	public Programmer() {
		
	}
	
	@Override 
	public void talkAboutYourself() {
		System.out.println("hello i am "+getName()+".");
		System.out.println("I am "+getAge()+" years old.");
		System.out.println("I am a programmer and I love "+programLanguage+".");
	}
}
