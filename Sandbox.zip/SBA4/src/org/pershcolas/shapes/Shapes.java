/**
 * 
 */
package org.pershcolas.shapes;

/**
 * Interface used for using these methods that are defined in Rectangle and Circle
 * @author Darril
 *
 */
public interface Shapes {

	public float getArea();
	
	public float getPerimeter();
	
	public String toString();
}
