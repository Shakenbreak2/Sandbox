package org.pershcolas.shapes;

public class Rectangle implements Shapes{
	
	private float length;
	private float width;
	private float area;
	private float perimeter;
	
	
	public Rectangle(float new_length, float new_width) {
		setLength(new_length);
		setWidth(new_width);
	}
	

	@Override
	public float getArea() {
		System.out.println("Finding area of rectangle with length="+length+" and width="+width);
		area=length*width;
		return area;
	}

	@Override
	public float getPerimeter() {
		System.out.println("Finding perimeter of rectangle with length="+length+" and width="+width);
		perimeter=2*(length+width);
		return perimeter;
	}
	
	@Override
	public String toString() {
		
		return "Rectangle = [length: "+length+", width: "+width+", area: "+area+", perimeter: "+perimeter+"]";
		
	}

	/**
	 * @return the length
	 */
	public float getLength() {
		return length;
	}

	/**
	 * @param length the length to set
	 */
	public void setLength(float length) {
		this.length = length;
	}

	/**
	 * @return the width
	 */
	public float getWidth() {
		return width;
	}

	/**
	 * @param width the width to set
	 */
	public void setWidth(float width) {
		this.width = width;
	}


}
