package org.pershcolas.shapes;

public class Square extends Rectangle {
	private float area, perimeter;
	
	public Square(float side) {
		super(side, side);
		// TODO Auto-generated constructor stub
	}
	
	public float getArea() {
		System.out.println("Finding area of square with side = "+getLength());
		super.getArea();
		area=getLength()*getWidth();
		return area;
	}

	public float getPerimeter() {
		System.out.println("Finding perimeter of square with side = "+getLength());
		super.getPerimeter();
		perimeter=4*(getLength());
		return perimeter;
	}
	
	@Override
	public String toString() {
		return "Square = [side: "+getLength()+", area: "+area+", perimeter: "+perimeter+"]";
	}
	
}
