package org.pershcolas.shapes;

import java.util.InputMismatchException;
import java.util.Scanner;

public class SBAMain {

	// declare fields that are used through out the class
	private static Scanner input = new Scanner(System.in);
	private static float length = 1, width = 1;
	private static float radius = 1;
	private static float side = 1;

	/**
	 * @see recInput input 2 float numbers
	 * @see squInput input 1 float number
	 * @see cirInput input 1 float number
	 * @param args
	 */
	public static void main(String[] args) {
		// declare objects that will be used
		Shapes rec = null, squ = null, cir = null;

		// input 2 numbers, does verification in method
		recInput();
		// instantiate object and pass length and width to perform calculations.
		rec = new Rectangle(length, width);

		// input 1 number, does verification in method
		squInput();
		// instantiate object and pass side to perform calculations.
		squ = new Square(side);

		// input 1 number, does verification in method
		cirInput();
		// instantiate object and pass radius to perform calculations.
		cir = new Circle(radius);

		// output calculations
		/**
		 * Finding area of rectangle with length=# and width=# 
		 * Finding perimeter of rectangle with length=2.0 and width=3.0 
		 * Area = 6.0 and Perimeter = 10.0
		 *
		 * Finding area of square with side = 2.0 
		 * Finding area of rectangle with length = 2.0 and width = 2.0
		 * Finding perimeter of square with side = 2.0 
		 * Finding perimeter of rectangle with length  =2.0 and width = 2.0 
		 * Area = 4.0 and Perimeter = 8.0
		 * 	
		 * Finding area of circle with radius = 4.0 
		 * Finding perimeter of circle with radius = 4.0
		 * Area = 50.24 and Perimeter = 25.12
		 * 
		 */
		System.out.println("====================================");
		System.out.println("Finding area and perimeter of shapes");
		System.out.println("====================================");

		System.out.println("Area = " + rec.getArea() + " and Perimeter = " + rec.getPerimeter());
		System.out.println();
		System.out.println("Area = " + squ.getArea() + " and Perimeter = " + squ.getPerimeter());
		System.out.println();
		System.out.println("Area = " + cir.getArea() + " and Perimeter = " + cir.getPerimeter());
		System.out.println();
		System.out.println("=========================");
		System.out.println("Printing Shapes as String");
		System.out.println("=========================");
		System.out.println(rec.toString());// output: "Rectangle = [length: #, width = #, area = #, parimeter = #]"
		System.out.println(squ.toString());// output: "Square = [length: #, width = #, area = #, parimeter = #]"
		System.out.println(cir.toString());// output: "Circle = [length: #, width = #, area = #, parimeter = #]"
	}

	/**
	 * gets input in String then converts to Float ten verifies that Float is between 2 and 99
	 */
	private static void cirInput() {
		String in = null;
		boolean good3 = false;
		
		//do-while to make sure that input is correct
		do {
			
			/**
			 * try 		:getting input String
			 * catch 	:if there is no input
			 * finally 	:try 	:convert String to Float value
			 * 			 catch 	:if input is not a Float value
			 * 	*/
			try {
				System.out.println("Enter the radius of the circle.");
				in = input.next();

			} catch (NullPointerException ex) {
				System.out.println("no input");
			} finally {
				try {
					radius = Float.parseFloat(in);
				} catch (NumberFormatException e) {
					System.out.println("input was not a number: i.e. 2.0");
				}
			}

			
			/**
			 * if	:length float value is between 2 and 99 
			 * 		return true;
			 * 			
			 * else	:return false;
			 */
			if (1 < radius && radius < 100) {
				good3 = true;
			} else {
				System.out.println(radius + " is not between 2 and 99");
				good3 = false;
			}
			
			//repeat if false
		} while (good3 == false);
	}

	/**
	 * gets input in String then converts to Float ten verifies that Float is between 2 and 99
	 */
	private static void squInput() {
		String in = null;
		boolean good3 = false;
		
		//do-while to make sure that input is correct
		do {
			
			/**
			 * try 		:getting input String
			 * catch 	:if there is no input
			 * finally	:try 	:convert String to Float value
			 * 			 catch 	:if input is not a Float value
			 * 	*/
			try {

				System.out.println("Enter the side of the square.");
				in = input.next();

			} catch (NullPointerException ex) {
				System.out.println("no input");
			} finally {
				try {
					side = Float.parseFloat(in);
				} catch (NumberFormatException e) {
					System.out.println("input was not a number: i.e. 2.0");
				}
			}
			
			
			/**
			 * if	:length float value is between 2 and 99 
			 * 		return true;
			 * 			
			 * else	:return false;
			 */
			if (1 < side && side < 100) {
				good3 = true;
			} else {
				System.out.println(side + " is not between 2 and 99");
				good3 = false;
			}

			//if false repeat
		} while (good3 == false);

	}

	/**
	 * gets input in String then converts to Float ten verifies that Float is between 2 and 99
	 */
	private static void recInput() {
		String in1 = null, in2 = null;
		boolean good = false;
		
		//do-while to make sure that input is correct
		do {
			//prompt for input
			System.out.println("Enter the length and width of the rectangle");

			/**
			 * try :getting input String
			 * catch :if there is no input
			 * finally :try :convert String to Float value
			 * 			catch :if input is not a Float value
			 * 			
			 */
			try {
				in1 = input.next();
			} catch (NullPointerException e) {
				System.out.println("please enter a number");

			} finally {
				try {
					length = Float.parseFloat(in1);
				} catch (NumberFormatException e) {
					System.out.println("error: input is not a float number");
				}
			}

			/**
			 * try :getting input String
			 * catch :if there is no input
			 * finally :try :convert String to Float value
			 * 			catch :if input is not a Float value
			 * 			
			 */
			try {
				in2 = input.next();
			} catch (NullPointerException e) {
				System.out.println("please enter a number");
			} finally {
				{

				}
				try {
					width = Float.parseFloat(in2);
				} catch (NumberFormatException e) {
					System.out.println("error: input is not a float number");
				}

			}

			/**
			 * if	:length float value is between 2 and 99 
			 * 		return true;
			 * 			:if	:width float value is between 2 and 99
			 * 				return true;
			 * 			:else	: return false;
			 * else	:return false;
			 */
//			System.out.println(length+" "+ width);
			if (1 < length && length < 100) {
				good = true;
				if (1 < width && width < 100) {
					good = true;
				} else {
					System.out.println("width is not between 2 and 99");
					good = false;
				}

			} else {
				System.out.println("length is not between 2 and 99");
				good = false;
			}
			
			//repeat if false
		} while (good == false);
	}

}
