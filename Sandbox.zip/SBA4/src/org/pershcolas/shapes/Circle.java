package org.pershcolas.shapes;

public class Circle implements Shapes{
	//declare fields
	private float radius,area, perimeter;
	
	//constructor that gets radius value
	public Circle(float new_radius) {
		setRadius(new_radius);
	}
	
	//calculates area of a circle
	@Override
	public float getArea() {
		System.out.println("Finding area of circle with radius = "+radius);
		area=(float) (3.14 * radius * radius);
		return area;
	}

	//calculates perimeter of circle
	@Override
	public float getPerimeter() {
		System.out.println("Finding perimeter of circle with radius = "+radius);
		perimeter=(float) (6.28 * radius);
		return perimeter;
	}
	
	//return string below
	@Override
	public String toString() {
		return "Circle = [radius: "+radius+", area: "+area+", perimeter: "+perimeter+"]";
	}

	//return radius
	public float getRadius() {
		return radius;
	}

	//set radius to input radius
	public void setRadius(float radius) {
		this.radius = radius;
	}

}
