package org.pershcolas.shapes.tests;

import java.util.InputMismatchException;
import java.util.Scanner;

import org.pershcolas.shapes.Circle;
import org.pershcolas.shapes.Rectangle;
import org.pershcolas.shapes.Shapes;
import org.pershcolas.shapes.Square;

public class SBATests {

	/**
	 * results of all test have already been moved into SBAMain.java into their own methods
	 * @param args
	 */
	
	
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		Shapes cir;

		float radius = 0;
		boolean good3 = false;

		String in = null;
		do {
			try {
				System.out.println("Enter the radius of the circle.");
				 in = input.next();
				
			} catch (NullPointerException ex) {
				System.out.println("no input");
			} finally {
				try {
					radius = Float.parseFloat(in);
				} catch (NumberFormatException e) {
					System.out.println("input was not a number: i.e. 2.0");
				}
			}

			if (1 < radius && radius < 100) {
				good3 = true;
			} else {
				System.out.println(radius + " is not between 2 and 99");
				good3 = false;
			}

		} while (good3 == false);

		cir = new Circle(radius);

		System.out.println(cir.toString());

	}

}
