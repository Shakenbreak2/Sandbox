package assignments;

public class Waterbottle {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
