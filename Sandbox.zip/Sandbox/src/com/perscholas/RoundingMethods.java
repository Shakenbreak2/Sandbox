package com.perscholas;

import java.util.Scanner;

public class RoundingMethods {
	
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		double num=input.nextDouble();
		System.out.println(num);
		
		input.close();
	}
	

}
