package com.perscholas;
//import java.util.Scanner;

public class Sandbox {

	public static void main(String[] args) {
		String n = " Valhalla ";
		String s1 = "We Die for Glory";
		System.out.println(n.length());
		System.out.println(n.charAt(3));
		System.out.println(n.concat(s1));
		System.out.println(n.toUpperCase());
		System.out.println(n.toLowerCase());
		System.out.println(n.trim());
		
	}

}
