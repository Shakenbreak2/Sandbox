package airline;

import java.util.Scanner;

/**Airlines seat booking
 * 
 * Scenario:
 * 1) A plane has 26 rows labeled from A to Z and 10 columns labeled from 1 to 10.
 * 2) There are two aisles on the plane. THe first aisle is after 3rd
 * 		column and the second aisle is after the 7th column.
 * 3) Families having 3 members want to seat together in adjacent 
 * 		seats but not separated by an aisle.
 * 4) Some seats are already booked i.e. A4, A10, C5, D3, E6, F8.
 * 
 * Input:
 * Take already booked seat numbers as String (comma - separted) from the keyboard.
 * 
 * Output:
 * The number of families who can seat together having the restriction mentioned in point 3.
 * As an example, output 10 means the airline company still can sell 30 tickets following the restriction.
 * 
 * @author  Darril Gaban
 * @author  Imad Killedar
 * @author  Mamadou Dembele
 * @author  Eugene Gines
 * @author  Madhubala Jampala 
 * @author  Valli
 *
 */

public class Main {
	// Darril
	public static void main(String[] args) {
		
		Seats book = new Seats();
		// creating a scanner object for user input
		Scanner scan = new Scanner(System.in);
		// creating a boolean to end the program
		boolean exit = false;
		System.out.println("Welcome to JJ air! To continue please press enter");
		

		// loop to continue entering seats until user exits program

		while (exit == false) {
			// try to catch any errors
			try {
				String input;
				input = scan.nextLine();

				System.out.println("Please enter the seats you would like to book:"
						+ " (Letter Number,)");

				input = scan.nextLine();
				// method to take user input and spilt it into row and columns
				book.enterSeats(input);
				// prints seating chart and it shows which seats available
				book.printPlane();
				// if try catches any error it prints the below statement
			} catch (Exception ex) {
				System.out.println("Please Enter a Valid Seat Number");

			}
			System.out.println("Would you like to book another seat? (1: Yes, 2:No)");
			String againString = scan.next();
			// check the user input to continue or exit the program
			if (againString.equals("1")) {
				exit = false;
			} else {
				exit = true;
			}
		}
		scan.close();
	}

}
