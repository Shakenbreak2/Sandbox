/**
 * 
 */
package airline;

import java.util.ArrayList;
import java.util.HashMap;

/**
 * @author  Darril Gaban
 * @author  Imad Killedar
 * @author  Mamadou Dembele
 * @author  Eugene Gines
 * @author  Madhubala Jampala 
 * @author  Valli
 */
public class Seats {
	private static String[][] seats = new String[26][10];
//	ArrayList< ArrayList<String>> array = new ArrayList< ArrayList<String>>();
//	private static HashMap<String, Integer> seatRows = new HashMap<String, Integer>();
	private static int counterFitFamily = 78;

	// default constructor
	public Seats() {

		popSeats();
	}

	// Eugene
	// method to populate seats 2D array with empty character (" ") instead of null
	private void popSeats() {

		for (int i = 0; i < 26; i++) {
//			array.add(i, new ArrayList<String>());
			for (int j = 0; j < 10; j++) {
//				array.get(i).add(" ");
				seats[i][j] = " ";
			}
		}
	}

	// method to check if seat is already b if seat is already b it will have you
	// enter
	// another seat
	// Imad
	private boolean bookSeats(int s, int num) {
		if (seats[s][num] == "b") {
			System.out.println("Seat is already booked, please choose another:");
			return false;
		} else {

			return true;
		}

	}

	// method to check how many families we can fit after booking
	public void output(int a) {

		if (seats[a][0] == "b" || seats[a][1] == "b" || seats[a][2] == "b") {
			counterFitFamily--;
		}
		if (seats[a][4] == "b" || seats[a][5] == "b") {
			counterFitFamily--;
		}
		if (seats[a][7] == "b" || seats[a][8] == "b" || seats[a][9] == "b") {
			counterFitFamily--;
		}
		if (seats[a][3] == "b" && seats[a][6] == "b") {
			counterFitFamily--;
		}

	}

	// Madhu
	// method to take input and split it into row and columns
	public void enterSeats(String seatbook) {
		int s = 0, num = 0;
		counterFitFamily = 78;
		// take input seats and split into array
		String[] b = seatbook.toLowerCase().split(",");
		// to separate alphabet and the integer
		for (int i = 0; i < b.length; i++) {
			String[] c = b[i].split("(?<=\\D)(?=\\d)");
			char ch = c[0].trim().charAt(0);
			num = Integer.parseInt(c[1]);
			
//			seatRows.put(c[0].trim(), Integer.parseInt(c[1]));

			
			// method to convert alphabet to row index
			s = convertRow(ch);
			
			
			if (bookSeats(s, num - 1)) {
				seats[s][num - 1] = "b";

			} else {
				System.out.println("This seat is already booked.");
			}

		}

		for (int j = 0; j < 26; j++) {
			output(j);

		}
		System.out.println();
		System.out.println("This is how many familys we can still seat: "
							+ counterFitFamily);
		System.out.println();
		System.out.println("Total seats for family seating remaining: "
							+ (counterFitFamily * 3));
	}
	
//	private void convRow(char row, int col)
//	{	
//		try {
//
//			switch (row) {
//			case 'a':
//				seatRows.put(0, col);
//				break;
//			case 'b':
//				seatRows.put(0, col);
//				break;
//			case 'c':
//				seatRows.put(0, col);
//				break;
//			case 'd':
//				seatRows.put(0, col);
//				break;
//			case 'e':
//				seatRows.put(0, col);
//				break;
//			case 'f':
//				seatRows.put(0, col);
//				break;
//			case 'g':
//				seatRows.put(0, col);
//				break;
//			case 'h':
//				seatRows.put(0, col);
//				break;
//			case 'i':
//				seatRows.put(0, col);
//				break;
//			case 'j':
//				seatRows.put(0, col);
//				break;
//			case 'k':
//				
//				break;
//			case 'l':
//				seatRows.put(0, col);
//				break;
//			case 'm':
//				seatRows.put(0, col);
//				break;
//			case 'n':
//				seatRows.put(0, col);
//				break;
//			case 'o':
//				seatRows.put(0, col);
//				break;
//			case 'p':
//				seatRows.put(0, col);
//				break;
//			case 'q':
//				seatRows.put(0, col);
//				break;
//			case 'r':
//				seatRows.put(0, col);
//				break;
//			case 's':
//				seatRows.put(0, col);
//				break;
//			case 't':
//				seatRows.put(0, col);
//				break;
//			case 'u':
//				seatRows.put(2, col);
//				break;
//			case 'v':
//				seatRows.put(21, col);
//				break;
//			case 'w':
//				seatRows.put(22, col);
//				break;
//			case 'x':
//				seatRows.put(23, col);
//				break;
//			case 'y':
//				seatRows.put(24, col);
//				break;
//			case 'z':
//				seatRows.put(25, col);
//				break;
//
//			}
//
//		} catch (Exception ex) {
//			System.out.println("Something went wrong");
//		}
//	}
	// Valli
	// mapping each ALPHABET to corresponding row index in the array
	private int convertRow(char row){
		int r = -1;
		try {

			switch (row) {
			case 'a':
				r = 0;
				break;
			case 'b':
				r = 1;
				break;
			case 'c':
				r = 2;
				break;
			case 'd':
				r = 3;
				break;
			case 'e':
				r = 4;
				break;
			case 'f':
				r = 5;
				break;
			case 'g':
				r = 6;
				break;
			case 'h':
				r = 7;
				break;
			case 'i':
				r = 8;
				break;
			case 'j':
				r = 9;
				break;
			case 'k':
				r = 10;
				break;
			case 'l':
				r = 11;
				break;
			case 'm':
				r = 12;
				break;
			case 'n':
				r = 13;
				break;
			case 'o':
				r = 14;
				break;
			case 'p':
				r = 15;
				break;
			case 'q':
				r = 16;
				break;
			case 'r':
				r = 17;
				break;
			case 's':
				r = 18;
				break;
			case 't':
				r = 19;
				break;
			case 'u':
				r = 20;
				break;
			case 'v':
				r = 21;
				break;
			case 'w':
				r = 22;
				break;
			case 'x':
				r = 23;
				break;
			case 'y':
				r = 24;
				break;
			case 'z':
				r = 25;
				break;

			}

		} catch (Exception ex) {
			System.out.println("Something went wrong");
		}
		return r;
	}

	// Mamadou
	// printing the seating chart
	public void printPlane() {
		for (int k = 0; k < 26; k++) {
			System.out.print("row " + k + " |");
			for (int l = 0; l < 10; l++) {
				if (l == 3 || l == 7) {
					System.out.print("* * *|" + seats[k][l] + " |");
				} else
					System.out.print(seats[k][l] + " |");
			}
			System.out.println();
		}
	}

}
