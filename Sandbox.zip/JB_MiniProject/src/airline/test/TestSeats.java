

/**
 * 
 */
package airline.test;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Scanner;

import airline.Seats;

/**
 * @author  Darril Gaban
 * @author  Imad Killedar
 * @author  Mamadou Dembele
 * @author  Eugene Gines
 * @author  Madhubala Jampala 
 * @author  Valli
 */
public class TestSeats {
//	private static String[][] seats = new String[26][10];
	private static ArrayList< ArrayList<String>> array = new ArrayList< ArrayList<String>>();
//	private static HashMap<String, Integer> seatRows = new HashMap<String, Integer>();
	private static int counterFitFamily = 78;

	// default constructor
	public TestSeats() {

		popSeats();
	}

	// Eugene
	// method to populate seats 2D array with empty character (" ") instead of null
	private void popSeats() {

		for (int i = 0; i < 26; i++) {
			array.add(i, new ArrayList<String>());
			for (int j = 0; j < 10; j++) {
				array.get(i).add(j," ");
//				seats[i][j] = " ";
			}
		}
	}

	// method to check if seat is already b if seat is already b it will have you
	// enter
	// another seat
	// Imad
	private boolean bookSeats(int s, int num) {
//		seats[s][num] == "b"
		if (array.get(s).get(num)=="b") {
			System.out.println("Seat is already booked, please choose another:");
			return false;
		} else {

			return true;
		}

	}

	// method to check how many families we can fit after booking
	public void output(int a) {
		
		if(array.get(a).get(0)=="b"||array.get(a).get(1)=="b"||array.get(a).get(2)=="b")
		{
			counterFitFamily--;
		}
		if(array.get(a).get(4)=="b"||array.get(a).get(5)=="b")
		{
			counterFitFamily--;
		}
		if(array.get(a).get(7)=="b"||array.get(a).get(8)=="b"||array.get(a).get(9)=="b")
		{
			counterFitFamily--;
		}
		if(array.get(a).get(3)=="b"&&array.get(a).get(6)=="b") {
			counterFitFamily--;
		}
		
//		if (seats[a][0] == "b" || seats[a][1] == "b" || seats[a][2] == "b") {
//			counterFitFamily--;
//		}
//		if (seats[a][4] == "b" || seats[a][5] == "b") {
//			counterFitFamily--;
//		}
//		if (seats[a][7] == "b" || seats[a][8] == "b" || seats[a][9] == "b") {
//			counterFitFamily--;
//		}
//		if (seats[a][3] == "b" && seats[a][6] == "b") {
//			counterFitFamily--;
//		}

	}

	// Madhu
	// method to take input and split it into row and columns
	public void enterSeats(String seatbook) {
		int s = 0, num = 0;
		counterFitFamily = 78;
		// take input seats and split into array
		String[] b = seatbook.toLowerCase().split(",");
		// to separate alphabet and the integer
		for (int i = 0; i < b.length; i++) {
			String[] c = b[i].split("(?<=\\D)(?=\\d)");
			char ch = c[0].trim().charAt(0);
			num = Integer.parseInt(c[1]);
			
			

			// method to convert alphabet to row index
			s = convertRow(ch);

			if (bookSeats(s, num - 1)) {
//				seats[s][num - 1] = "b";
				array.get(s).add(num,"b");

			} else {
				System.out.println("This seat is already booked.");
			}

		}

		for (int j = 0; j < 26; j++) {
			output(j);

		}
		System.out.println();
		System.out.println("This is how many familys we can still seat: "
							+ counterFitFamily);
		System.out.println();
		System.out.println("Total seats for family seating remaining: "
							+ (counterFitFamily * 3));
	}
	

	// Valli
	// mapping each ALPHABET to corresponding row index in the array
	private int convertRow(char row) {
		int r = -1;
		try {

			switch (row) {
			case 'a':
				r = 0;
				break;
			case 'b':
				r = 1;
				break;
			case 'c':
				r = 2;
				break;
			case 'd':
				r = 3;
				break;
			case 'e':
				r = 4;
				break;
			case 'f':
				r = 5;
				break;
			case 'g':
				r = 6;
				break;
			case 'h':
				r = 7;
				break;
			case 'i':
				r = 8;
				break;
			case 'j':
				r = 9;
				break;
			case 'k':
				r = 10;
				break;
			case 'l':
				r = 11;
				break;
			case 'm':
				r = 12;
				break;
			case 'n':
				r = 13;
				break;
			case 'o':
				r = 14;
				break;
			case 'p':
				r = 15;
				break;
			case 'q':
				r = 16;
				break;
			case 'r':
				r = 17;
				break;
			case 's':
				r = 18;
				break;
			case 't':
				r = 19;
				break;
			case 'u':
				r = 20;
				break;
			case 'v':
				r = 21;
				break;
			case 'w':
				r = 22;
				break;
			case 'x':
				r = 23;
				break;
			case 'y':
				r = 24;
				break;
			case 'z':
				r = 25;
				break;

			}

		} catch (Exception ex) {
			System.out.println("Something went wrong");
		}
		return r;
	}

	// Mamadou
	// printing the seating chart
	public void printPlane() {
		for (int k = 0; k < 26; k++) {
			System.out.print("row " + k + " |");
			for (int l = 0; l < 10; l++) {
				if (l == 3 || l == 7) {
					System.out.println("* * *|"+array.get(k).get(l)+" |");
//					System.out.print("* * *|" + seats[k][l] + " |");
				} else
					System.out.println(array.get(k).get(l)+ " |");
//					System.out.print(seats[k][l] + " |");
			}
			System.out.println();
		}
	}
	
//=======================================================================	


	// Darril
	public static void main(String[] args) {
		
		Seats book = new Seats();
		// creating a scanner object for user input
		Scanner scan = new Scanner(System.in);
		// creating a boolean to end the program
		boolean exit = false;
		System.out.println("Welcome to JJ air! To continue please press enter");
		

		// loop to continue entering seats until user exits program

		while (exit == false) {
			// try to catch any errors
			try {
				String input;
				input = scan.nextLine();

				System.out.println("Please enter the seats you would like to book:"
						+ " (Letter Number,)");

				input = scan.nextLine();
				// method to take user input and spilt it into row and columns
				book.enterSeats(input);
				// prints seating chart and it shows which seats available
				book.printPlane();
				// if try catches any error it prints the below statement
			} catch (Exception ex) {
				System.out.println("Please Enter a Valid Seat Number");

			}
			System.out.println("Would you like to book another seat? (1: Yes, 2:No)");
			String againString = scan.next();
			// check the user input to continue or exit the program
			if (againString.equals("1")) {
				exit = false;
			} else {
				exit = true;
			}
		}
		scan.close();
	}

}
