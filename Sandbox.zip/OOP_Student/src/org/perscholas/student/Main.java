package org.perscholas.student;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		IAfterGrad grad = new Graduate();
		
		
		grad= new Graduate(true, "application development", "perscholas", "Ronald", "02/21/94");
		grad.walk();
		grad.talk();
		grad.learn();
		if(grad.isCertified()) {
			grad.done();
		}
		System.out.println(grad.getName()+" born: "+grad.getDob()+" is a "+grad.getCourse()+" student of "+grad.getOrganization());
		grad.happy();
		grad.continuelearing();
		
	}

}
