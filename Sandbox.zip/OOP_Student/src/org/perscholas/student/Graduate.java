/**
 * 
 */
package org.perscholas.student;

/**
 * @author Darril
 *
 */
public class Graduate extends Student 
implements IAfterGrad
{

	private boolean certified;
	/**
	 * 
	 */
	public Graduate() {
		// TODO Auto-generated constructor stub
	}
	public Graduate(boolean certified, String course, String organization, String name, String dob) {
		super(course,organization,name,dob);
		this.setCertified(certified);
	}
	
	public void done()
	{
		System.out.println("I am a professional java developer");
	}
	/**
	 * @return the certified
	 */
	public boolean isCertified() {
		return certified;
	}
	/**
	 * @param certified the certified to set
	 */
	public void setCertified(boolean certified) {
		this.certified = certified;
	}
}
