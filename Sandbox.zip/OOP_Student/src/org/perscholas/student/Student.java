/**
 * 
 */
package org.perscholas.student;

/**
 * @author Darril
 *
 */
public class Student extends Person {
	
	private String course;
	private String organization;
	/**
	 * 
	 */
	public Student() {
		
	}
	
	public Student(String course, String organization, String name, String dob) {
		super(name,dob);
		this.setCourse(course);
		this.setOrganization(organization);
		
	}
	
	public void learn()
	{
		System.out.println(this.getName()+" is learning");
	}

	/**
	 * @return the course
	 */
	public String getCourse() {
		return course;
	}

	/**
	 * @param course the course to set
	 */
	public void setCourse(String course) {
		this.course = course;
	}

	/**
	 * @return the organization
	 */
	public String getOrganization() {
		return organization;
	}

	/**
	 * @param organization the organization to set
	 */
	public void setOrganization(String organization) {
		this.organization = organization;
	}
}
