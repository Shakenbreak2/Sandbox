/**
 * 
 */
package org.perscholas.student;

/**
 * @author Darril
 *
 */
public interface IAfterGrad {
	
	public default void happy() {
		System.out.println("I am happpy");
	}
	
	public default void continuelearing() {
		System.out.println("now you need to continue learning");
	}
	

	public void done();
	
	public void setCertified(boolean certified);

	public void walk();

	public String getName();

	public String getDob();

	public String getCourse();

	public String getOrganization();

	public boolean isCertified();

	public void learn();

	public void talk();
}
