/**
 * 
 */
package org.perscholas.student;

/**
 * @author Darril
 *
 */
public class Person {

	private String name;
	private String dob;
	/**
	 * 
	 */
	public Person() {
		
	}
	
	public Person(String name, String dob) {
		this.setName(name);
		this.setDob(dob);
		
	}
	
	public void talk() {
		System.out.println(name+" is talking");
	}
	
	public void walk()
	{
		System.out.println(name+" is walking");
	}

	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * @return the dob
	 */
	public String getDob() {
		return dob;
	}

	/**
	 * @param dob2 the dob to set
	 */
	public void setDob(String dob2) {
		this.dob = dob2;
	}
}
