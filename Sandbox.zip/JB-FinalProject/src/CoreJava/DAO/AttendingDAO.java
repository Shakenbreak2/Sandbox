package CoreJava.DAO;

import CoreJava.Models.Attending;
import CoreJava.Models.Course;
import CoreJava.Models.Student;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class AttendingDAO {
	private List<Attending> attending = new ArrayList<Attending>();
	private String location = "..\\eclipse-workspace\\JB-FinalProject\\src\\attending.csv";

	public List<Attending> getAttending() {
		try {
			File file = new File(location);
			Scanner input = new Scanner(file);
			while (input.hasNext()) {
				String[] line = input.nextLine().split(",");

				attending.add(new Attending(Integer.parseInt(line[0]), line[1]));

			}
			input.close();
		} catch (FileNotFoundException e) {
			System.out.println("file not found");
			e.getStackTrace();
		} finally {

		}
		return attending;
	}

	public void registerStudentToCourse(List<Attending> attending, String studentEmail, int courseID) {
		Attending newAttendy = new Attending(courseID, studentEmail);
		boolean found=false;
		/**
		 * if :attending list does not contains instance of newAttendy :add object
		 * newAttendy to attending list else :print student already registered
		 */
		try {
			for(Attending attend: attending) {
				if (attend.getCourseID()==courseID && attend.getStudentEmail().equals(studentEmail)) {
					System.out.println("student already registerd to this course");
					found=true;
					break;
				} else {
					
				}
			}
			
		}catch(Exception e) {
			System.out.println("error: something");
		}
			if(found==false) {
				attending.add(newAttendy);
				saveAttending(attending);
			}
	}

	public List<Course> getStudentCourses(List<Course> courseList, List<Attending> attending, String studentEmail) {
		
		List<Course> studentCourses = new ArrayList<Course>(); 
		
		
		/**
		 * for 	:each object, check if that object has studentEmail 
		 * 		:if :object has studentEmail, get course Id,
		 * 			:compare course Id to course list, 
		 * 			:if	:course matches course id
		 * 			:	:course to courselist
		 */
		try {
		for (Attending a : attending) {
			if (a.getStudentEmail().equals(studentEmail)) {
				int s= a.getCourseID();
				
				for(Course c: courseList) {
					if(c.getID()==s) {
						studentCourses.add(c);
					}
				}
			}
		}
		}catch(Exception e) {
			Course s = new Course("0","n/a","n/a");
			for(int i=0; i<studentCourses.size();i++)
				studentCourses.add(s);
		}
		return studentCourses;

	}
	

	public void saveAttending(List<Attending> attending) {
		String s = null;
		try {
			File file = new File(location);
			FileWriter w = new FileWriter(file, false);
			for (Attending a : attending) {
				s = a.getCourseID() + ","  + a.getStudentEmail()+"\n";
				w.write(s);
			}
			w.close();
		} catch (FileNotFoundException e) {
			System.out.println("error: file not found");
			e.getStackTrace();

		} catch (IOException e) {
			System.out.println("error: something happened while writing to file.");
		}
	}

}
