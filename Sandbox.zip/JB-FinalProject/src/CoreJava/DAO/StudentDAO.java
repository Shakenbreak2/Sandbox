package CoreJava.DAO;

import CoreJava.Models.Student;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class StudentDAO {
	private List<Student> studentList = new ArrayList<Student>();
	

	public List<Student> getStudents() {
		try {
			File file = new File("C:\\Users\\Student\\eclipse-workspace\\JB-FinalProject\\src\\students.csv");
			Scanner input = new Scanner(file);
			while (input.hasNext()) {
				String[] line = input.nextLine().split(",");

				studentList.add(new Student(line[0], line[1], line[2]));

			}
			input.close();
		} catch (FileNotFoundException e) {
			System.out.println("file not found");
			e.getStackTrace();
		}
		return studentList;
	}

	public Student getStudentByEmail(List<Student> studentList, String studentEmail) {
		Student student = new Student();
		
		try {
			for(Student s: studentList) {
				String e=s.getEmail();
				if(e.equals(studentEmail)) {
					student=s;
					
				}
				
			}
		}catch(Exception e) {
			
		}
		return student;
		

	}

	public boolean validateUser(List<Student> studentList, String studentEmail, String studentPass) {
		
		
			for (int i=0; i<studentList.size();i++) {
				String e=studentList.get(i).getEmail();
				String p=studentList.get(i).getPass();
				
				if(e.equals(studentEmail) && p.equals(studentPass)) {
					return true;
				}
			}return false;
			
		

	}
}
