package CoreJava.Models;

public class Course {
	private int courseID;
	private String courseName, instructor;
	
	public Course() {}
	
    public Course(String courseID, String courseName, String instructor) {
		super();
		
		setID(Integer.parseInt(courseID));
		setName(courseName);
		setInstructor(instructor);
	}

	public void setID(int ID){
		this.courseID = ID;
    }

    public int getID(){
    	return this.courseID;
    }

    public void setName(String name){
    	this.courseName=name;
    }

    public String getName(){
    	return this.courseName;
    }

    public void setInstructor(String instructor){
    	this.instructor = instructor;
    }

    public String getInstructor(){
    	return this.instructor;
    }

}
