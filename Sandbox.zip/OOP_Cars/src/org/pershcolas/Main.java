package org.pershcolas;

public class Main {

	public static void main(String[] args) {
		Car myCar = new Car();
		Car anotherCar = new Car("box", "B6-42502895", "yellow","srV", "honda", 6.0, 2011);
		
		SUV mySuv = new SUV();
		
		myCar.drive();
		mySuv.drive();
		
		mySuv.setSeats(7);
		
	}

}
