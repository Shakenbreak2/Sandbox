package org.pershcolas;

public class Car {
	private String shape;
	private String vin;
	private String color;
	private String model;
	private String make;
	private double engSize;
	private int year;
	
	public Car(String shape,String vin, String color, String model, String make, double engSize, int year) {
		this.shape= shape;
		this.vin= vin;
		this.color= color;
		this.model = model;
		this.make = make;
		this.engSize= engSize;
		this.year=year;
	}
	public Car() {}
	
	
	public void drive() {
		System.out.println("go, go, go");
	}
	
	public void brake() {
		System.out.println("Slow down");
	}
	
	public void turn() {
		System.out.println("turn");
	}
	
	public void start() {
		System.out.println("engine start");
	}

	/**
	 * @return the shape
	 */
	public String getShape() {
		return shape;
	}

	/**
	 * @param shape the shape to set
	 */
	public void setShape(String shape) {
		this.shape = shape;
	}

	/**
	 * @return the vin
	 */
	public String getVin() {
		return vin;
	}

	/**
	 * @param vin the vin to set
	 */
	public void setVin(String vin) {
		this.vin = vin;
	}

	/**
	 * @return the color
	 */
	public String getColor() {
		return color;
	}

	/**
	 * @param color the color to set
	 */
	public void setColor(String color) {
		this.color = color;
	}

	/**
	 * @return the model
	 */
	public String getModel() {
		return model;
	}

	/**
	 * @param model the model to set
	 */
	public void setModel(String model) {
		this.model = model;
	}

	/**
	 * @return the make
	 */
	public String getMake() {
		return make;
	}

	/**
	 * @param make the make to set
	 */
	public void setMake(String make) {
		this.make = make;
	}

	/**
	 * @return the engSize
	 */
	public double getEngSize() {
		return engSize;
	}

	/**
	 * @param engSize the engSize to set
	 */
	public void setEngSize(double engSize) {
		this.engSize = engSize;
	}

	/**
	 * @return the year
	 */
	public int getYear() {
		return year;
	}

	/**
	 * @param year the year to set
	 */
	public void setYear(int year) {
		this.year = year;
	}
}
