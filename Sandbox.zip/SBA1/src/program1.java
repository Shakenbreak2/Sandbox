import java.util.Scanner;

public class program1 {
	static Scanner input = new Scanner(System.in);

	public static void main(String[] args) {
		/*
		 * 1. Write a program to sum up all the even numbers until the 25th number in
		 * the Fibonacci series.
		 * 
		 * 
		 * 2. A word is said to be �abecedarian� if the letters in the word appear in
		 * alphabetical order. For example, the following are all 6-letter English
		 * abecedarian words.
		 * 
		 * abdest, acknow, acorsy, adempt, adipsy, agnosy, befist, behint, beknow,
		 * bijoux, biopsy, cestuy, chintz, deflux, dehors, dehort, deinos, diluvy,
		 * dimpsy
		 * 
		 * Write a program for checking whether a given word (String) is abecedarian,
		 * assuming that the word contains only lower-case letters. Your process can be
		 * iterative or recursive.
		 */

		int menu = 0;
		while (menu != 3) {
			System.out.println("which option: 1) fibonacci 2) abecedarian 3)exit");
			menu = input.nextInt();

			switch (menu) {
			case 1:
				fibonacci();
				break;
			case 2:
				abecedarian();
				break;
			case 3:
				System.out.println("goodbye");
				break;
			default:
				System.out.println("not valid option");
			}

		}
		// close scanner
		input.close();

	}

	static void fibonacci() {
		int j = 0, k = 1;// numbers used in fibonacci
		int sum = 0, evenSum = 0;// sums used to calculate sums, and even numbers
		
		
		//loop till get through 25 iterations
		for (int i = 1; i < 25; i++) {

			// find the fibonacci sequence
			System.out.println(j);
			sum = j + k;//find sum of previous 2 numbers
			j = k;//set first number to equal to 2nd number
			k = sum;//set second number to equal to sum

			// if current fibonacci number is even add it to evenSum
			if (j % 2 == 0)
				evenSum += j;

		}
		// print out even sum
		System.out.println("even sum of the fibonacci sequence to the 25th number: " + evenSum);

	}

	static void abecedarian() {

		// get word input from user
		System.out.println("please enter a word");
		String s = input.next().toLowerCase().trim();

		// set letter to first letter in string
		char letter = s.charAt(0);
		
		//check if input string is abcedarian
		if(recursive(s, letter)) {
			System.out.println("word is abcedarian");
		
		}else
			System.out.println("word is not abcedarain");
			
//		// loop through entire string
//		for (int i = 1; i < s.length(); i++) {
//
//			// check if current letter is later in the
//			// alphabet than the next character in string
//			if (letter > s.charAt(i)) {
//				System.out.println(s + " is not abecedarian");
//				break;
//			} else if (i == s.length() - 1) {
//				// if entire word is abecedarian. print this
//				System.out.println(s + " is abecedarian");
//			} else {
//				// if current letter is before the next in the alphabet,
//				// set new letter to next
//				letter = s.charAt(i);
//
//			}
//
//		}

	}

	static boolean recursive(String s, char a) {
		//if string is empty return true because word is abcedarian
			if(s.isEmpty()) {
				return true;
			}else {//check first letter is greater than the next
				//if next letter is smaller than the previous return false
				if(a>s.charAt(0))
					return false;
				else//if next letter is greater, check next 2 letters 
					return recursive(s.substring(1), s.charAt(0));
			}
			
		
	}
}
