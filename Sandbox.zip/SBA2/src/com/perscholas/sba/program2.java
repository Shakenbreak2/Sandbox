package com.perscholas.sba;

import java.util.HashMap;
import java.util.Scanner;

public class program2 {
	// declaring and initializing a 2d HashMap
	static HashMap<Integer, HashMap<Integer, String>> board = new HashMap<Integer, HashMap<Integer, String>>();
//		String[][] board = new String[8][8];

//+++++++++++++++
	public static void main(String[] args) {

		// declare and initialize variables
		Scanner in = new Scanner(System.in);
		int ka = -1, kb = -1, kingA = -1, kingB = -1;

		/**
		 * this is to populate the HashMap board with " " spaces
		 */
		for (int i = 0; i < 8; i++) {
			for (int k = 0; k < 8; k++) {
				if (!board.containsKey(i)) {
					board.put(i, new HashMap<Integer, String>());
				}
				board.get(i).put(k, "  ");
			}
		}

		/**
		 * this is the king position input prompts user for two numbers
		 * 
		 * @checkIn verifies that the 2 input numbers are 0<x<9 if not 1-8, prompts user
		 *          for new numbers.
		 */
		{
			System.out.println("where do you want to place the king (1-8):");
			kingA = in.nextInt();
			kingB = in.nextInt();
		}
		while (checkIN(kingA, kingB))
			;

		// outputs where you put the king
		System.out.println("king is at " + (kingA) + " " + (kingB));

		// inputs the position of king onto board array
		board.get(kingA - 1).put(kingB - 1, "King");

		/**
		 * this is the knight position input verifies that knight is not the same
		 * position as king.
		 * 
		 * @checkIN verifies that input numbers are 0-8
		 */
		do {
			System.out.println("Now where is the knight (1-8):");
			ka = in.nextInt();
			kb = in.nextInt();
			// checks if numbers are the same as the king
			if (ka == kingA && kb == kingB) {

				System.out.println("king is already there");
				ka = -1;
				kb = -1;
			}
		} while (checkIN(ka, kb));

		// outputs the position of knight
		System.out.println("knight is at " + (ka) + " " + (kb));

		// inputs position of knight onto board
		board.get(ka - 1).put(kb - 1, "knight");

		/**
		 * @knightMove checks for possible knight moves and sees if king is in check
		 */
		knightMove(ka, kb, kingA, kingB);
		System.out.println();

		// prints out the board
		for (int i = 0; i < 8; i++) {
			System.out.print((i + 1) + "|");
			for (int j = 0; j < 8; j++) {
				System.out.print(board.get(i).get(j) + "	|");
			}
			System.out.println();
		}

	}

	/**
	 * checks whether the knight's possible moves are overlaping with the king's
	 * spot 
	 * 
	 * @param knightRow
	 * @param knightColumn
	 * @param kingRow
	 * @param kingColumn
	 */
	static void knightMove(int knightRow, int knightColumn, int kingRow, int kingColumn) {
//		a+2,b+1;//up,right
//		a+2,b-1;//up,left
//		a-2,b+1;//down,right
//		a-2,b-1;//down,left
//		a+1,b+2;//right, up
//		a-1,b+2;//right, down
//		a+1,b-2;//left, up
//		a-1,b-2;//left, down

		// initialize 2 arrays for knights row and column movement
		int[] rowMove = { 2, 2, -2, -2, 1, -1, 1, -1 };
		int[] columnMove = { 1, -1, 1, -1, 2, 2, -2, -2 };
		// declare check values to see if knight possible move is at king's spot
		int checkA = -1, checkB = -1;

		/**
		 * Loops to check all knight's possible moves and sees whether if it is in
		 * bounds if in bounds, inputs a "*" at those coordinates on board HashMap
		 * array.
		 * 
		 * 
		 * then checks whether the possible move spot is at the kings spot
		 */
		System.out.print("Knight's possible move: ");
		for (int i = 0; i < 8; i++) {

			if (knightRow + rowMove[i] > 0 && knightColumn + columnMove[i] > 0 && knightRow + rowMove[i] < 9
					&& knightColumn + columnMove[i] < 9) {

				System.out.printf("{%d,%d}, ", knightRow + rowMove[i], knightColumn + columnMove[i]);

				// get the String value that is at the position of the knights possible move
				String value = board.get((knightRow + rowMove[i]) - 1).get((knightColumn + columnMove[i]) - 1);

				// String builder to concatenate the String value that is there and "*"
				StringBuilder sb = new StringBuilder(value + " *");
				// turn that String builder back into a string
				value = sb.toString();
				// put new value back into that array that we got the original value at
				board.get((knightRow + rowMove[i]) - 1).put((knightColumn + columnMove[i]) - 1, value);

			} else {
				continue;
			}

			// checks if knight move is at king spot if so
			// replace checkA and checkB values to those coordinates
			if (knightRow + rowMove[i] == kingRow && knightColumn + columnMove[i] == kingColumn) {
				checkA = kingRow;
				checkB = kingColumn;
			}

		}

		// checks if checkA and checkB vales are not -1 if so first spot
		// if not display king is in check
		if (checkA == -1 && checkB == -1) {
			System.out.println();
			System.out.print("king is not checked:");
		} else {
			System.out.println();
			System.out.printf("king is in check at %d, %d : ", checkA, checkB);
		}
	}

	/**
	 * check if user input value are with in the bounds of 1-8 
	 * 
	 * @param a is row value
	 * @param b is column value
	 * @return true if values are not within 1-8
	 * @return false if values are within 1-8
	 */
	static boolean checkIN(int a, int b) {
		if (a > 0 && a < 9) {
			if (b > 0 && b < 9) {
				return false;
			} else
				return true;
		} else
			return true;

	}

}
