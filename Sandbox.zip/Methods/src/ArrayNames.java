import java.util.Arrays;
import java.util.ArrayList;
import java.util.Scanner;

public class ArrayNames {
	static ArrayList<String> students = new ArrayList<String>();
	static String positions[][] = new String[10][10];
	static Scanner in = new Scanner(System.in);

	public static void populateMap() {
		//populates positions array,(map) with * so it doesn't display null
		
		for (int i = 0; i < positions.length; i++) {
			for (int j = 0; j < positions.length; j++) {
				positions[i][j] = "*";
			}
		}
	}

	public static void enterName(String name) {
		// enter name into array
		// not used currently
		
		System.out.println("welcome " + name);
		students.add(name);

	}

	public static void enterStudentPosition(String student, int spot1, int spot2) {
		/* puts student on to grid. */

		positions[spot1][spot2] = student;

	}

	static void findStudent(String getID) {
		//find position of student on the grid and display coordinates
		
		
		String fullArray = Arrays.deepToString(positions);
		
//checks if user input name is on the map
		if (fullArray.contains(getID)) {
			System.out.println(getID+" is on the map");
			
			//runs loop to find exact coordinates that name is in array and display
			for(int i=0;i<positions.length;i++) {
				for(int j=0;j<positions[i].length;j++) {
					if(positions[i][j].equals(getID)) {
						System.out.println(getID+" is at "+j+" , "+i);

					}
					
				}
			}
			
		} else//display if user input name is not on the map
			System.out.println(getID+" is not on the map");

	}

	public static void printMap(String name) {
		// prints positions array with all students on map
		
		for (int i = 0; i < positions.length; i++) {
			for (int j = 0; j < positions[i].length; j++) {
				System.out.print("|	" + positions[i][j] + "	|");
			}
			System.out.println();
		}
	}
}
