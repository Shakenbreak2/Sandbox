import java.util.Scanner;

public class TestMethods {
//	static int index = 0;
	static Scanner in = new Scanner(System.in);
	static String name;

	public static void main(String[] args) {
		int menu;
		
		ArrayNames.populateMap();
		do {
			System.out.println("" + "\nWhat do you wish to do?" + "\n" + "1)enter new student\n"
					+ "2)find student on map\n" + "3)print map\n" + "4)exit\n");
			menu = in.nextInt();
			switch (menu) {
			case 1:
				addStudent();
				break;
			case 2:
				findStudents();
				break;
			case 3:
				ArrayNames.printMap(name);
				break;
			case 4:
				break;

			}
		} while (menu != 4);

	}

	/*
	 * asks user for name input then coordinates that they will be on the map,
	 * map is positions[][].
	 */
	public static void addStudent() {
		System.out.println("What is the name of the student");
		name = in.next().trim();

		ArrayNames.enterName(name);

		System.out.println("where is student on the map? (0-9,0-9)");
		System.out.println("on x axis");
		int spot1 = in.nextInt();
		System.out.println("now on y axis");
		int spot2 = in.nextInt();
		ArrayNames.enterStudentPosition(name, spot2, spot1);

//		index++;
	}

	/*gets input for student that user wishes to finds then passes 
	 * value to findStudents method to find their coordinates in positions[][].
	*/
	public static void findStudents() {
		System.out.println("Which student do you wish to find?");
		String name2 = in.next().trim();

		ArrayNames.findStudent(name2);
	}

}
