
import java.util.Scanner;

public class ArgumentEnter {
	static Scanner in = new Scanner(System.in);
	static int[] scores;

	// enter name
	public static String studentName() {
		System.out.println("What is your name?");
		String name = in.nextLine();
		return name;

	}

	// get exam scores
	public static int[] exams(String name) {

		System.out.println("Lets find the scores of " + name + "?");
		System.out.println("What is the number of Exams?");
		int exams = in.nextInt(); // input size of array
		System.out.println("now enter the scores");
		scores = new int[exams]; // declare array size

		// input into array
		for (int i = 0; i < exams; i++) {
			int tem = 101;// declare checksum to validate input with

			// while loop to make sure input is within proper bounds
			while (tem < 0 || tem > 100) {
				System.out.printf("Enter exam# %d score:", i + 1);
				tem = in.nextInt();// enter input
				if (tem < 0 || tem > 0)// outputs if input is out of bounds
					System.out.println("Please enter a number from 0-100");
				else
					continue;// exit while loop if input is within bounds
			}

			// assigns validated input to array at index i
			scores[i] = tem;

		}

		// returns array with all values
		return scores;
	}

	// print all the scores
	public static void printScores(int[] scores, String name) {
		System.out.printf("the scores %s got are:\n", name);

		for (int i = 0; i < scores.length; i++) {
			System.out.println((i + 1) + ") " + scores[i]);
		}
	}

	// find min, max, and total scores
	public static void score(int[] scores) {
		int min = scores[0]; // sets min as first value of the array
		int max = scores[0]; // sets max as first value of the array
		double total = 0;

		for (int i : scores) {
			// total adds score at current index
			total += i;

			// checks if current index is less than min
			if (i < min) {
				min = i;
			}

			// checks if current index is more than max
			if (i > max)
				max = i;
		}

		// out puts total, min, and max
		System.out.println("total score is: " + total);
		System.out.println("min score is: " + min);
		System.out.println("max score is: " + max);

	}

//	public static int maxScore(int[] scores) {
//		int max=0;
//		
////		for(int i=0;i<scores.length;i++) {
////			if(scores[i]>scores[i+1])
////				max=scores[i];
////		}
//		
//		return max;
//	}
}
