
public class Game {

	public static void main(String[] args) {
		
		String name=ArgumentEnter.studentName(); //get name here
		int[] scores = ArgumentEnter.exams(name);//pass name into method and get array of scores
		ArgumentEnter.printScores(scores, name);//pass scores and name to output all elements of array
		ArgumentEnter.score(scores);//find and print min, max, and total values of the elements of array
		
	}

}
