import java.util.Scanner;

public class numbersTable {

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		boolean palendrome = false;
		
		String word = input.next();
			
		for(int i=0, j=word.length()-1; i<word.length() && j>0; i++, j--) {
			char lastLetter = word.charAt(j);
			char firstLetter = word.charAt(i);
			System.out.println(firstLetter+ " "+ lastLetter);
			if(firstLetter == lastLetter) {
				if(i==j) {
					palendrome = true;
					break;
				}
			}else {
				palendrome = false;
				break;
			}
			palendrome = true;
		}
		
		if(palendrome== true) {
			System.out.println("word is palendrome");
		}else {
			System.out.println("word is not palendrome");
		}
		

	}

}
