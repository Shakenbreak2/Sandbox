import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

public class ExceptionTestMain {

	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);

		String email, name, password;
		boolean goodN=false,good=false,goodP=false;
		do {
			System.out.println("enter email");
			email = in.next();
			if(email.matches("^[A-Za-z0-9+_.-]+@(.+)$")) {
				good=true;
			}else
				good=false;
		} while (good==false);
		do {
			System.out.println("enter name");
			name = in.next();
			if(name.matches("^[A-Za-z]+[\\w]+[A-Za-z]+$")) {
				goodN=true;
			}else
				goodN=false;
		} while (goodN == false);
		System.out.println("enter password");
			password = in.next();
//		do {
//			
//			if(password.matches("((?=.*[a-z])(?=.*d)(?=.*[@#$%])(?=.*[A-Z]).{10})")) {
//				goodP=true;
//			}else
//				goodP=false;
//		} while (goodP==false);

		String entry ="\n"+email+", "+name+", "+password;
		System.out.println(entry);

		writeFile("C:\\Users\\Student\\eclipse-workspace\\Files\\Students.txt", entry);

		readFile("C:\\Users\\Student\\eclipse-workspace\\Files\\Students.txt");
		
		in.close();
	}

	public static void createFile(String location) throws AlreadyCreatedException, IOException {
		File file = new File(location);
		if(!file.exists()) {
			file.createNewFile();
		}else
			throw new AlreadyCreatedException("File already created");
	}

	public static void writeFile(String location,String inputString) {
		try {
			File file = new File(location);
			FileWriter w= new FileWriter(file , true);
			w.write(inputString);
			w.close();
		}catch(FileNotFoundException e) {
			System.out.println("error: file not found");
			e.getStackTrace();
			
				try {
					createFile(location);
				}catch(AlreadyCreatedException ex) {
					System.out.println("error: file already created");
					ex.getStackTrace();
				}catch(IOException ex) {
					System.out.println("error: something happened while creating file.");
				}
			
		}catch(IOException e) {
			System.out.println("error: something happened while writing to file.");
		}
		
	}

	public static void readFile(String location) {

		ArrayList<String[]> arr = new ArrayList<String[]>();

		try {
			File file = new File(location);

			Scanner input = new Scanner(file);
			while (input.hasNext()) {
				String line = input.nextLine();
				arr.add(line.split(","));
			}
			for (String[] s : arr) {
				System.out.format("%-25s | %-15s | %-15s \n",s[0],s[1],s[2]);
//				System.out.println(s[0] + "	| " + s[1] + "	| " + s[2]);
				
			}
			input.close();

		} catch (FileNotFoundException e) {
			System.out.println("file not found");
			e.getStackTrace();
		} finally {
			System.out.println("hope that worked.");
		}
	}
}
