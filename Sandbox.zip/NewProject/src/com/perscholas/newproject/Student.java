package com.perscholas.newproject;

public class Student {
	private String name;
	private int course;
	private double javaScore;
	private double sqlScore;
	private double webScore;

	public Student() {

	}

	public Student(String name, int course, double javaScore, double sqlScore, double webScore) {
		this.name=name;
		this.course=course;
		this.javaScore = javaScore;
		this.sqlScore = sqlScore;
		this.webScore = webScore;
	}

	public Student(String name, int course) {
		this.name = name;
		this.course = course;
	}

	public void inClass() {
		System.out.println(name + " is learing Java in course: " + course);
		
	
	}

	private void pass(double score) {
		if (70<=score) {
			System.out.println(name+" of course: "+course+" is passing with a score of: "+score);
		}

	}

	private void fail(double score) {
		if (70 >score) {
			System.out.println(name+" of course: "+course+" is failing with a score of: "+score);
		}
	}

	public void avg() {
		double score= ((javaScore+sqlScore+webScore)/3);
		System.out.println(score);
		pass(score);
		fail(score);
	}
}
