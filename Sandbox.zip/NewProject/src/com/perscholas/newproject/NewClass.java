package com.perscholas.newproject;

import java.util.Scanner;

public class NewClass {

	public static void main(String[] args) {
		Student student;
		Scanner in=new Scanner(System.in);
		
		System.out.println("What is your name.\n"
				+ "What course are you taking.");
		String name=in.nextLine();
		int course=in.nextInt();
		
		student=new Student(name, course);
		student.inClass();
		
		System.out.println("What are your scores in Java, SQL, Web");
		double java=in.nextDouble();
		double sql=in.nextDouble();
		double web=in.nextDouble();
		
		student=new Student(name,course,java, sql, web);
		
		student.avg();
		
		in.close();

	}

}
