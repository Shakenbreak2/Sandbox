package org.perscholas.reviewproject.week11;

import java.util.Scanner;

public class Review {

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in); 
		double number=0, num2=0;
		
		do {
			System.out.println("Enter a number");
			number=input.nextInt();
			
			System.out.println("enter 2nd number");
			num2=input.nextInt();
			
			if(checkIfNegative(number, num2)==true) {
				if(checkIfZero(number, num2)==true) {
					System.out.println("can't divide by 0");
				}else {
					sum(number, num2);
					minus(number, num2);
					divide(number, num2);
				}
			}else {
				System.out.println("please no negative numbers");
			}
		}while(checkIfNegative(number, num2)==false);
//		if(number<0||num2<0) {
//			System.out.println("Thank you");
//			
//		}else if(number == 0|| num2 == 0) {
//			System.out.println("error: can't divide by 0");
//		}else{
//			System.out.println(number + " + "+ num2 + " = "+(number+num2));
//			System.out.println(number + " - "+ num2 + " = "+(number-num2));
//			System.out.println(number + " / "+ num2 + " = "+(number/num2));
//			
//		}
		
//		}while(number < 0||num2 < 0);
	}
	
	private static boolean checkIfNegative(double number, double num2) {
		if(number<0||num2<0) {
			return false;
		}else
			return true;
	}
	
	private static boolean checkIfZero(double number, double num2) {
		if(number==0||num2==0) {
			return true;
		}else
			return false;
	}
	
	private static void sum(double number, double num2) {
		System.out.println(number+num2);
	}
	
	private static void minus(double number, double num2) {
		System.out.println(number-num2);
	}
	
	private static void divide(double number, double num2) {
		System.out.println(number/num2);
	}

}
