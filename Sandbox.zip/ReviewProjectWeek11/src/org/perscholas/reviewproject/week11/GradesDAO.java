package org.perscholas.reviewproject.week11;


import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;



public class GradesDAO {
	
	private String location = "../ReviewProjectWeek11/src/org/perscholas/reviewproject/week11/grades.csv";
	
	public List<Grades> getGrades(){
		List<Grades> grades = new ArrayList<Grades>();
		try {
			File file = new File(location);
			Scanner input = new Scanner(file);
			while (input.hasNext()) {
				String[] line = input.nextLine().split(",");

				grades.add(new Grades(Integer.parseInt(line[0]), line[1], Integer.parseInt(line[2]), Integer.parseInt(line[3]),Integer.parseInt(line[4])));
				
			}
			input.close();
		} catch (FileNotFoundException e) {
			System.out.println("file not found");
			e.getStackTrace();
		} finally {

		}
		
		return grades;
		
	}
	
	public void addStudent(List<Grades> grades) {
		Scanner input = new Scanner(System.in);
		System.out.println("Add student id");
		int id = input.nextInt();
		System.out.println("Add student initials eg. DG");
		String name = input.next();
		System.out.println("Add grade 1");
		int grade1 = input.nextInt();
		System.out.println("Add grade 2");
		int grade2 = input.nextInt();
		System.out.println("Add grade 3");
		int grade3 = input.nextInt();
		
		grades.add(new Grades(id, name, grade1, grade2, grade3));
		
		saveGrades(grades);
	}
	
	public void getScores(List<Grades> grades) {
		
		
		for(int i=0;i<grades.size();i++) {
			calculateAvg(grades.get(i));
		}
	}
	
	
	public void calculateAvg(Grades grades2) {
		int num1 =grades2.getNum1();
		int num2 =grades2.getNum2();
		int num3 =grades2.getNum3();
		
		double avg = (num1+num2+num3)/3;
		
		System.out.println("name: "+grades2.getName()+" grade1: "+num1+ " grade2: "+num2+" grade3: "+num3+" average: "+avg);
	}
	
	public void changeGrades(List<Grades> grades) {
		Scanner input = new Scanner(System.in);
		System.out.println("What is the ID of the student?");
		
		int id = input.nextInt();
		
			for(Grades g: grades) {
				if(id == g.getId()) {
					System.out.println("Which grade do you wish to change:");
					int whichGrade = input.nextInt();
						switch(whichGrade) {
						case 1:System.out.println("Enter the grade: ");g.setNum1(input.nextInt());break;
						case 2:System.out.println("Enter the grade: ");g.setNum2(input.nextInt());break;
						case 3:System.out.println("Enter the grade: ");g.setNum3(input.nextInt());break;
							default:System.out.println("chose not to change grades");
								
						}
					saveGrades(grades);
					
				}
				else {
					continue;
				}
			}
		
	}
	
	public void saveGrades(List<Grades> grades) {
		String s = null;
		String location2 = "../ReviewProjectWeek11/src/org/perscholas/reviewproject/week11/grades.csv";
		try {
			File file = new File(location2);
			FileWriter w = new FileWriter(file, false);
			for (Grades a : grades) {
				s = a.getId()+","+a.getName()+","+a.getNum1()+","+a.getNum2()+","+a.getNum3()+"\n";
				w.write(s);
			}
			w.close();
		} catch (FileNotFoundException e) {
			System.out.println("error: file not found");
			e.getStackTrace();

		} catch (IOException e) {
			System.out.println("error: something happened while writing to file.");
		}
	}
	
	public void saveAvg(List<Grades> grades) {
		String s = null;
		String location2 = "../ReviewProjectWeek11/src/org/perscholas/reviewproject/week11/Result.txt";
		try {
			File file = new File(location2);
			FileWriter w = new FileWriter(file, false);
			for (Grades a : grades) {
				s = a.getName() + "," + ((a.getNum1()+a.getNum2()+a.getNum3())/3)+"\n";
				w.write(s);
			}
			w.close();
		} catch (FileNotFoundException e) {
			System.out.println("error: file not found");
			e.getStackTrace();

		} catch (IOException e) {
			System.out.println("error: something happened while writing to file.");
		}
	}
	

}
