package org.perscholas.reviewproject.week11;

import java.util.List;
import java.util.Scanner;

public class StudentExamReview {

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		GradesDAO start =new GradesDAO();
		
		List<Grades> grades = start.getGrades();
		
		System.out.println("What do you wish to do? \n 1)see scores \n 2)change grades \n 3)add student");
		int choice = input.nextInt();
			switch(choice) {
			case 1:start.getScores(grades);
					start.saveAvg(grades);
					break;
			case 2:start.changeGrades(grades);
					break;
			case 3:start.addStudent(grades);
					break;
			default:System.out.println("good bye");break;
			}
	
		
		

	}

}
